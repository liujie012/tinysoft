<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2018/5/30
 * Time: 下午2:22
 */


$the_host = $_SERVER['HTTP_HOST'];//取得当前域名
$request_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';//判断地址后面是否有参数

if (in_array($the_host, [
    'tinysoft.org',
    'www.tinysoft.org',
    'tiebazhushou.com',
    'tool.tiebazhushou.com',
    'tools.tiebazhushou.com',
    'www.tiebazhushou.com',

]))//把这里的域名换上你想要的
{
    header('HTTP/1.1 301 Moved Permanently');//发出301头部
    header('Location: http://www.xiaogongju.org');//跳转到你希望的地址格式
    exit;
}


date_default_timezone_set("PRC");

define('TINY', __DIR__);

//ip 139.129.140.133
define('CDN', 'https://static.tinygroup.cn');

define('APP', TINY . '/app');

define('CORE', TINY . '/core');

define('MODULE', 'app');

define('DEBUG', false);


include TINY . '/vendor/autoload.php';


include CORE . '/common/function.php';
include CORE . '/tiny.php';

if (DEBUG) {

    $whoops = new \Whoops\Run;
    $whoops->pushHandler(new \Whoops\Handler\PrettyPageHandler);
    $whoops->register();
    ini_set('display_error', 'On');

} else {
    ini_set('display_error', 'Off');

}


spl_autoload_register('core\Tiny::load');


core\Tiny::run();


function dd($info) {
    print_r($info);
    exit;
}

