<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2018/3/1
 * Time: 下午4:30
 */




function Config($name) {


    $config = [
        'host' => 'qdm70682163.my3w.com',
        'user' => 'qdm70682163',
        'password' => 'Hello123456',
        'database' => 'qdm70682163_db'
    ];



    return $config[$name];
}