<?php
header('Location: https://www.tiebazhushou.com/output.zip');//跳转到你希望的地址格式
exit;