<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2019-01-18
 * Time: 15:20
 */

namespace core\lib;

use Medoo\Medoo;
use core\lib\config;

class model extends Medoo {

    public function __construct() {

        $options = config::all('database');

        parent::__construct($options);
    }
}