<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2019-01-07
 * Time: 14:25
 */

namespace core\lib;

use core\Tiny;
use think\Exception;

class config {

    public static $config = [];

    /**
     * 获取一个配置内容
     * @param $name
     * @param $file
     * @return mixed
     * @throws Exception
     */
    public static function get($name, $file) {
        if (isset(self::$config[$file][$name])) {
            return self::$config[$file][$name];
        }

        $file_path = CORE . '/config/' . $file . '.php';

        if (!is_file($file_path)) {
            throw new Exception("config file not existence");
        }

        $file_config = include $file_path;

        if (!isset($file_config[$name])) {
            throw new Exception("config variable {$name} not existence");
        }

        self::$config[$file] = $file_config;

        return $file_config[$name];

    }

    /**
     * 获取所有配置
     * @param $file
     * @return mixed
     * @throws Exception
     */
    public static function all($file) {
        if (isset(self::$config[$file])) {
            return self::$config[$file];
        }

        $file_path = CORE . '/config/' . $file . '.php';

        if (!is_file($file_path)) {
            throw new \Exception("config file not existence");
        }

        $file_config = include $file_path;


        self::$config[$file] = $file_config;

        return $file_config;
    }

}
