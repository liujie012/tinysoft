<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2018/5/30
 * Time: 下午4:18
 */

namespace core\lib;

class route {
    public $controller;
    public $action;

    public function __construct() {

        $path = $_SERVER['REQUEST_URI'];

        if (!empty($path) && ($path != '/')) {

            $path = str_replace('/index.php', '', $path);
            $path = str_replace('/index1.php', '', $path);
            $path = str_replace('/index2.php', '', $path);
            $path = str_replace('.html', '', $path);


            $path_info = explode('/', trim($path, '/'));
            $this->controller = empty($path_info[0]) ? 'Index' : ucfirst($path_info[0]);
            unset($path_info[0]);
            $this->action = empty($path_info[1]) ? 'index' : $path_info[1];
            unset($path_info[1]);

            $count = count($path_info) + 2;
            $i = 2;
            while ($i < $count) {
                if (isset($path_info[$i + 1])) {
                    $_GET[$path_info[$i]] = $path_info[$i + 1];
                }
                $i += 2;
            }


        } else {
            $this->controller = 'Index';
            $this->action = 'index';
        }

    }
}