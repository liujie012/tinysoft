<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2018/5/30
 * Time: 下午3:17
 */

namespace core;

use core\lib\route;

class Tiny {

    public $data = [];

    public static $classMap = [];

    public static function load($class) {

        if (!isset(self::$classMap[$class])) {
            $class = str_replace('\\', '/', $class);
            $file = TINY . '/' . $class . '.php';
            if (is_file($file)) {
                include $file;
            } else {
                return false;
            }
            self::$classMap[$class] = $class;
        }

        return true;

    }

    public static function run() {

        $route = new route();
        $controller = $route->controller;
        $action = $route->action;

        $controller_file = APP . '/controllers/' . $controller . 'Controller.php';
        $controller_path = '\\' . MODULE . '\controllers\\' . $controller . 'Controller';


        if (is_file($controller_file)) {
            include_once $controller_file;

            $controller = new $controller_path();
            $controller->$action();

        } else {
            echo "<a href='https://www.tiebazhushou.com'>home</a>";exit;
            throw new \Exception("不存在的类" . $controller . $action);
        }
    }

    public function assign($name, $value) {
        $this->data[$name] = $value;
    }

    public function display($file) {
        extract($this->data);
        $file =  APP . '/views/' . $file . '.html';

        ob_start();

        include $file;

        $content = ob_get_clean();

        include APP . "/views/main.html";
    }


}