<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2018/3/1
 * Time: 下午4:34
 */


//error_reporting(E_ERROR);

define('APP_PATH', __DIR__);
define('APP', APP_PATH . '/app'); //tiny项目目录

include_once APP_PATH . '/config.php';

include_once APP_PATH . '/tool/mysql.php';

include_once APP_PATH . '/tool/tool.php';


$variable = [];

function assign($key, $value) {

    global $variable;

    $variable[$key] = $value;

}


function display($page) {

    global $variable;

    extract($variable);

    ob_start();

    include APP_PATH . "/html/{$page}.html";

    $content = ob_get_clean();

    include APP_PATH . "/html/main.html";

}
