<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2018-12-26
 * Time: 17:00
 */


//header('Content-type:text/json');
error_reporting(E_ALL);
ini_set("display_errors","on");





$lang_url = $_REQUEST['lang_url'];

$host = 'https://dwz.cn';
$path = '/admin/v2/create';
$url = $host . $path;
$method = 'POST';
$content_type = 'application/json';


$token = "21f8ff2ffd3c5574ba5ddc3dd4fcae6f";

$res = file_get_contents($url);
print_r($res);exit;
// TODO：设置待注册长网址
$bodys = array('url' => $lang_url);

// 配置headers
$headers = array('Content-Type:' . $content_type, 'Token:' . $token);
var_dump(123);
// 创建连接
$curl = curl_init($url);
curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
curl_setopt($curl, CURLOPT_FAILONERROR, false);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_HEADER, false);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($bodys));

// 发送请求
$response = curl_exec($curl);

$rew = curl_getinfo($curl);

var_dump($rew);

curl_close($curl);


var_dump($response);
// 读取响应
echo $response;exit;

