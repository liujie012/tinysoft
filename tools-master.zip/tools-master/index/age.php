<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2018-12-24
 * Time: 17:48
 */

include "../include.php";
include_once '../tool/Carbon.php';
include_once '../tool/year.php';

$year = !empty($_GET['year']) ? $_GET['year'] : 2000;
$month = !empty($_GET['month']) ? $_GET['month'] : date('m');
$day = !empty($_GET['day']) ? $_GET['day'] : date('d');

$birthday = $year . '-' . $month . '-' . $day;

$tool = new tool();
$birth_info = $tool->birthdayInfo($birthday);

$live_monty = Carbon::parse($birthday)->diffInMonths();

$last_monty = 900 - $live_monty;
$last_monty = $last_monty <= 0 ? '很多' : $last_monty;


//公历农历转换
$lunar = new year();//生成对象
$lunar_calendar_date = $lunar->convertLunarToSolar($year, $month, $day); //公历转农历
$date = $lunar->getYearZodiac($year, $month, $day); //根据阴历年获取生肖
$date = $lunar->isLeapYear($year, $month, $day); //判断闰年
//其它功能也是这种调用方法
//print_r($date);
//如果是农历转公历，代码如下：
//$date = $lunar->convertLunarToSolar(2014,2,12); //农历转公历
//print_r($date);

$title = "年龄计算器";
$keywords = "年龄计算,星座查询,属相查询,起名字,五行查询,算命,公历阴历查询";
$description = "年龄计算,星座查询,属相查询,起名字,五行查询,算命,公历阴历查询";

assign('title', $title);
assign('keywords', $keywords);
assign('description', $description);

assign('year', $year);
assign('month', $month);
assign('day', $day);
assign('birth_info', $birth_info);
assign('birthday', $birthday);
assign('live_monty', $live_monty);
assign('last_monty', $last_monty);
assign('lunar_calendar_date', $lunar_calendar_date);

display('age');



