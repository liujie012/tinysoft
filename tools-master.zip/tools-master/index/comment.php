<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2019-01-02
 * Time: 22:20
 */


include "../include.php";


$title = "投诉建议";
$keywords = "年龄计算,星座查询,属相查询,起名字,五行查询,算命,公历阴历查询";
$description = "年龄计算,星座查询,属相查询,起名字,五行查询,算命,公历阴历查询";

assign('title', $title);
assign('keywords', $keywords);
assign('description', $description);

if (strtoupper($_SERVER['REQUEST_METHOD']) == 'POST') {
    $content = !empty($_POST['content']) ? htmlspecialchars(addslashes($_POST['content'])) : '';
    $username = !empty($_POST['username']) ? htmlspecialchars(addslashes($_POST['username'])) : '';
    $email = !empty($_POST['email']) ? htmlspecialchars(addslashes($_POST['email'])) : '';
    $user_ip = $_SERVER['REMOTE_ADDR'];

    if($content && $username && $email) {
        $data = [];
        $data['content'] = $content;
        $data['nickname'] = $username;
        $data['email'] = $email;
        $data['user_ip'] = $user_ip;
        $data['created_at'] = date('Y-m-d H:i:s');

        //todo 这个mysql类字符串插入有问题
        foreach($data as &$v) {
            $v = "'" . $v . "'";
        }

        $host = Config('host');
        $user = Config('user');
        $password = Config('password');
        $database = Config('database');

        $db = new mysql($host, $user, $password, $database);

        $db->select_table('user_comment');
        $db->data($data);
        $res = $db->add();

        assign('message', '提交失败');
        if($res) {
            assign('message', '提交成功');
        }


    } else {
        assign('message', '你要干啥？');
    }

    display('comment_success');


}else{
    display('comment');
}


