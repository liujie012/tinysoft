<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2019-01-02
 * Time: 21:17
 */


include "../include.php";




$title = "工资计算器 | 个税计算器2019 - 个人所得税计算器2019";
$keywords = "工资计算,2019年工资计算,个税计算,2019年个税计算,个人所得税计算器,个税累计预扣法,个税计算器,个税计算器2019,个人所得税";
$description = "2019年最新个人所得税计算器，采用2019年最新个税税率表，提供工资、税后工资、年终奖、劳务报酬等个税累计预扣预缴计算方法，2019年最好用的个税计算器,个税管理专家。";





$amount = isset($_GET['amount']) ? intval($_GET['amount']) : 0;


assign('amount', $amount);
assign('after_tax_income', $amount);



assign('title', $title);
assign('keywords', $keywords);
assign('description', $description);


display('taxpayer');