<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2018/6/5
 * Time: 下午4:52
 */

namespace app\controllers;

use core\lib\config;
use app\models\CityModel;
use app\models\IDModel;
use Carbon\Carbon;
use core\tiny;

class IndexController extends tiny {


    public function id() {
        header("Content-type:text/html;charset=utf-8");
        $city_model = new CityModel();
        $id_model = new IDModel();

        $id = !empty($_GET['id']) ? $_GET['id'] : 513436;
        $year = !empty($_GET['year']) ? $_GET['year'] : 2000;
        $month = !empty($_GET['month']) ? $_GET['month'] : date('m');
        $day = !empty($_GET['day']) ? $_GET['day'] : date('d');
        $sex = !empty($_GET['sex']) ? urldecode($_GET['sex']) : '男';

        //获取当前选中的省市区列表
        $province_list = $city_model->getCityListByParentID();
        $city_list = $city_model->getCityListByParentID(substr($id, 0, 2));
        $county_list = $city_model->getCityListByParentID(substr($id, 0, 4));
        $id_list = [];
        $name_list = [];

        for ($i = 0; $i < 30; $i++) {
            $id_list[] = $id_model->createId($id, $year, $month, $day, $sex);
            $name_list[] = $id_model->getFirstName() . $id_model->getLastName();

        }

        $this->assign('province_list', $province_list);
        $this->assign('city_list', $city_list);
        $this->assign('county_list', $county_list);
        $this->assign('id', $id);
        $this->assign('year', $year);
        $this->assign('month', $month);
        $this->assign('day', $day);
        $this->assign('sex', $sex);
        $this->assign('id_list', $id_list);
        $this->assign('name_list', $name_list);
        $this->assign('seo', config::get(__FUNCTION__, 'seo'));


        $this->display('id');


    }


    public function index() {

        $city_model = new CityModel();
        $id_model = new IDModel();
        $province_list = $city_model->getCityListByParentID();

        $id = !empty($_GET['id']) ? $_GET['id'] : 513436;
        $year = !empty($_GET['year']) ? $_GET['year'] : 2000;
        $month = !empty($_GET['month']) ? $_GET['month'] : date('m');
        $day = !empty($_GET['day']) ? $_GET['day'] : date('d');
        $sex = !empty($_GET['sex']) ? urldecode($_GET['sex']) : '男';


        $id_list = [];
        $name_list = [];

        for ($i = 0; $i < 30; $i++) {
            $id_list[] = $id_model->createId($id, $year, $month, $day, $sex);
            $name_list[] = $id_model->getFirstName() . $id_model->getLastName();

        }

        $this->assign('province_list', $province_list);
        $this->assign('id', $id);
        $this->assign('year', $year);
        $this->assign('month', $month);
        $this->assign('day', $day);
        $this->assign('sex', $sex);
        $this->assign('id_list', $id_list);
        $this->assign('name_list', $name_list);
        $this->assign('seo', config::get(__FUNCTION__, 'seo'));


        $this->display('index');

    }


    /**
     * 根据父id获取城市列表
     */
    public function citylist() {
        $parent_id = intval($_POST['id']);
        $city_model = new CityModel();
        $city_list = $city_model->getCityListByParentID($parent_id);
        echo json_encode($city_list);
    }

    public function check() {
        header("Content-type:text/html;charset=utf-8");

        $id = !isset($_GET['id']) ? '' : addslashes($_GET['id']);
        $sfz = new IDModel();
        $city_model = new CityModel();

        $info = $sfz->parseIDInfo($id);

        $province = $city_model->getOne($info['province']);
        $city = $city_model->getOne($info['province'] . $info['city']);
        $county = $city_model->getOne($info['province'] . $info['city'] . $info['county']);
        $sex = $sfz->getSexByNumber($info['sex']);
        $real_last_number = $sfz->getLastNumber($id);
        $user_last_number = substr($id, -1, 1);

        $this->assign('info', $info);
        $this->assign('province', $province);
        $this->assign('city', $city);
        $this->assign('county', $county);
        $this->assign('sex', $sex);
        $this->assign('real_last_number', $real_last_number);
        $this->assign('user_last_number', $user_last_number);
        $this->assign('seo', config::get(__FUNCTION__, 'seo'));


        $this->display('check');
    }


    /**
     * 短网址
     */
    public function shorturl() {

        $this->assign('seo', config::get(__FUNCTION__, 'seo'));

        $this->display('shorturl');
    }

    public function english() {


        $model = new \core\lib\model;
        $english = $model->rand('english', ['word', 'translate'], ["LIMIT" => 100]);

        $this->assign('seo', config::get(__FUNCTION__, 'seo'));

        $this->assign('english', $english);


        $this->display('english');


    }

    public function replace() {

        $this->assign('seo', config::get(__FUNCTION__, 'seo'));

        $this->display('replace');
    }

    public function buy() {

        $this->display('buy');
    }

}