<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2019-03-25
 * Time: 14:31
 */

namespace app\controllers;


use core\tiny;

class ArticleController extends tiny {

    public function index() {
        $this->display('article');
    }
}