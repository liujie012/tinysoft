<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2018/5/30
 * Time: 下午3:43
 */

namespace app\controllers;

class User {

    public function __construct() {
        echo 1;
    }
}