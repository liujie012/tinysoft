<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2019-03-25
 * Time: 11:20
 */

namespace app\controllers;



class TestController {

    public function index() {
        echo 'email: qibuluo@163.com';
    }
}