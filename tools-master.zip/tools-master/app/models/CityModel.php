<?php

namespace app\models;

use core\lib\model;

class CityModel extends model {
    public $table = 'area_code';

    //获取所有表数据
    public function getLists() {
        $ret = $this->select($this->table, '*');
        return $ret;
    }

    //获取单条数据
    public function getOne($id) {
        $ret = $this->get($this->table, '*', ['id' => $id]);
        return $ret;
    }

    //更新单条数据
    public function setOne($id, $data) {
        return $this->update($this->table, $data, ['id' => $id]);

    }

    //获取单条数据
    public function getOneByRandom($condition) {
        $ret = $this->rand($this->table, '*', $condition);
        return $ret;
    }


    /**
     * 根据父id获取当前所以的城市列表
     * @param int $parent_id
     * @return array|bool
     */
    public function getCityListByParentID($parent_id = 0) {
        $parent_id = intval($parent_id);
        $res = $this->select($this->table, '*', ['parent_id' => $parent_id]);
        return $res;
    }


}





