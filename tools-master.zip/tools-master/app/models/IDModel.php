<?php
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 2019-03-13
 * Time: 13:27
 */

namespace app\models;

use core\lib\model;

class IDModel {

    public function parseIDInfo($id) {
        if (strlen($id) != 18) {
            return [];
        }

        $info = [];
        $info['province'] = substr($id, 0, 2);
        $info['city'] = substr($id, 2, 2);
        $info['county'] = substr($id, 4, 2);
        $info['year'] = substr($id, 6, 4);
        $info['month'] = substr($id, 10, 2);
        $info['day'] = substr($id, 12, 2);
        $info['birthday'] = $info['year'] . '-' . $info['month'] . '-' . $info['day'];
        $info['sex'] = substr($id, 16, 1);
        $info['last'] = substr($id, 17, 1);

        return $info;
    }


    public function getCityListByParentID($parent_id = 0) {
        $parent_id = intval($parent_id);
        $sql = "select * from area_code where parent_id = {$parent_id}";
        $res = $this->db->fetchAll($sql);
        return $res;
    }

    public function getCityInfoByID($id) {
        $id = intval($id);
        $sql = "select `name` from area_code where id = {$id}";
        $res = $this->db->fetchOne($sql);
        return $res;
    }

    /**
     * 创建身份证号码
     * @param $id
     * @param $year
     * @param $month
     * @param $day
     * @param $sex
     * @return string
     */
    public function createId($id, $year, $month, $day, $sex) {

        $sex_number = $this->getSexNumber($sex);

        //随机生成的出生顺序从6开始，尽量避免和正常人身份证号重合
        $ID = $id . $year . $month . $day . mt_rand(6, 9) . mt_rand(0, 9) . $sex_number;

        $last = $this->getLastNumber($ID);

        $ID .= $last;

        return $ID;

    }

    /**
     * 获取最后一位身份证号
     * @param $ID
     * @return int|mixed
     */
    public function getLastNumber($ID) {

        if(!$ID) return '';

        $salt = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2];

        $sum = 0;

        for ($i = 0; $i < 17; $i++) {

            $sum += $ID[$i] * $salt[$i];
        }

        $last = $sum % 11;

        $last_arr = [1, 0, 'X', 9, 8, 7, 6, 5, 4, 3, 2];

        $last = $last_arr[$last];

        return $last;
    }


    /**
     * 根据性别获取性别的标识号
     * @param $sex
     * @return mixed
     */
    private function getSexNumber($sex) {

        $sex_number_info = ['男' => [1, 3, 5, 7, 9], '女' => [0, 2, 4, 6, 8]];

        $sex_number_arr = isset($sex_number_info[$sex]) ? $sex_number_info[$sex] : [1, 3, 5, 7, 9];

        $key = array_rand($sex_number_arr);

        $sex_number = $sex_number_arr[$key];

        return $sex_number;
    }

    public function getSexByNumber($sex_number) {

        if (in_array($sex_number, [1, 3, 5, 7, 9])) {
            return '男';
        } elseif (in_array($sex_number, [0, 2, 4, 6, 8])) {
            return '女';
        }

    }

    public function getFirstName() {
        $xing = array('赵', '钱', '孙', '李', '周', '吴', '郑', '王', '冯', '陈', '褚', '卫', '蒋', '沈', '韩', '杨', '朱', '秦', '尤', '许', '何', '吕', '施', '张', '孔', '曹', '严', '华', '金', '魏', '陶', '姜', '戚', '谢', '邹', '喻', '柏', '水', '窦', '章', '云', '苏', '潘', '葛', '奚', '范', '彭', '郎', '鲁', '韦', '昌', '马', '苗', '凤', '花', '方', '任', '袁', '柳', '鲍', '史', '唐', '费', '薛', '雷', '贺', '倪', '汤', '滕', '殷', '罗', '毕', '郝', '安', '常', '傅', '卞', '齐', '元', '顾', '孟', '平', '黄', '穆', '萧', '尹', '姚', '邵', '湛', '汪', '祁', '毛', '狄', '米', '伏', '成', '戴', '谈', '宋', '茅', '庞', '熊', '纪', '舒', '屈', '项', '祝', '董', '梁', '杜', '阮', '蓝', '闵', '季', '贾', '路', '娄', '江', '童', '颜', '郭', '梅', '盛', '林', '钟', '徐', '邱', '骆', '高', '夏', '蔡', '田', '樊', '胡', '凌', '霍', '虞', '万', '支', '柯', '管', '卢', '莫', '柯', '房', '裘', '缪', '解', '应', '宗', '丁', '宣', '邓', '单', '杭', '洪', '包', '诸', '左', '石', '崔', '吉', '龚', '程', '嵇', '邢', '裴', '陆', '荣', '翁', '荀', '于', '惠', '甄', '曲', '封', '储', '仲', '伊', '宁', '仇', '甘', '武', '符', '刘', '景', '詹', '龙', '叶', '幸', '司', '黎', '溥', '印', '怀', '蒲', '邰', '从', '索', '赖', '卓', '屠', '池', '乔', '胥', '闻', '莘', '党', '翟', '谭', '贡', '劳', '逄', '姬', '申', '扶', '堵', '冉', '宰', '雍', '桑', '寿', '通', '燕', '浦', '尚', '农', '温', '别', '庄', '晏', '柴', '瞿', '阎', '连', '习', '容', '向', '古', '易', '廖', '庾', '终', '步', '都', '耿', '满', '弘', '匡', '国', '文', '寇', '广', '禄', '阙', '东', '欧', '利', '师', '巩', '聂', '关', '荆', '司马', '上官', '欧阳', '夏侯', '诸葛', '闻人', '东方', '赫连', '皇甫', '尉迟', '公羊', '澹台', '公冶', '宗政', '濮阳', '淳于', '单于', '太叔', '申屠', '公孙', '仲孙', '轩辕', '令狐', '徐离', '宇文', '长孙', '慕容', '司徒', '司空');
        $key = array_rand($xing);
        return $xing[$key];
    }

    public function getLastName() {
        $name = array('伟', '刚', '勇', '毅', '俊', '峰', '强', '军', '平', '保', '东', '文', '辉', '力', '明', '永', '健', '世', '广', '志', '义', '兴', '良', '海', '山', '仁', '波', '宁', '贵', '福', '生', '龙', '元', '全', '国', '胜', '学', '祥', '才', '发', '武', '新', '利', '清', '飞', '彬', '富', '顺', '信', '子', '杰', '涛', '昌', '成', '康', '星', '光', '天', '达', '安', '岩', '中', '茂', '进', '林', '有', '坚', '和', '彪', '博', '诚', '先', '敬', '震', '振', '壮', '会', '思', '群', '豪', '心', '邦', '承', '乐', '绍', '功', '松', '善', '厚', '庆', '磊', '民', '友', '裕', '河', '哲', '江', '超', '浩', '亮', '政', '谦', '亨', '奇', '固', '之', '轮', '翰', '朗', '伯', '宏', '言', '若', '鸣', '朋', '斌', '梁', '栋', '维', '启', '克', '伦', '翔', '旭', '鹏', '泽', '晨', '辰', '士', '以', '建', '家', '致', '树', '炎', '德', '行', '时', '泰', '盛', '雄', '琛', '钧', '冠', '策', '腾', '楠', '榕', '风', '航', '弘', '秀', '娟', '英', '华', '慧', '巧', '美', '娜', '静', '淑', '惠', '珠', '翠', '雅', '芝', '玉', '萍', '红', '娥', '玲', '芬', '芳', '燕', '彩', '春', '菊', '兰', '凤', '洁', '梅', '琳', '素', '云', '莲', '真', '环', '雪', '荣', '爱', '妹', '霞', '香', '月', '莺', '媛', '艳', '瑞', '凡', '佳', '嘉', '琼', '勤', '珍', '贞', '莉', '桂', '娣', '叶', '璧', '璐', '娅', '琦', '晶', '妍', '茜', '秋', '珊', '莎', '锦', '黛', '青', '倩', '婷', '姣', '婉', '娴', '瑾', '颖', '露', '瑶', '怡', '婵', '雁', '蓓', '纨', '仪', '荷', '丹', '蓉', '眉', '君', '琴', '蕊', '薇', '菁', '梦', '岚', '苑', '婕', '馨', '瑗', '琰', '韵', '融', '园', '艺', '咏', '卿', '聪', '澜', '纯', '毓', '悦', '昭', '冰', '爽', '琬', '茗', '羽', '希', '欣', '飘', '育', '滢', '馥', '筠', '柔', '竹', '霭', '凝', '晓', '欢', '霄', '枫', '芸', '菲', '寒', '伊', '亚', '宜', '可', '姬', '舒', '影', '荔', '枝', '丽', '阳', '妮', '宝', '贝', '初', '程', '梵', '罡', '恒', '鸿', '桦', '骅', '剑', '娇', '纪', '宽', '苛', '灵', '玛', '媚', '琪', '晴', '容', '睿', '烁', '堂', '唯', '威', '韦', '雯', '苇', '萱', '阅', '彦', '宇', '雨', '洋', '忠', '宗', '曼', '紫', '逸', '贤', '蝶', '菡', '绿', '蓝', '儿', '翠', '烟');

        $count = mt_rand(1, 2);

        $name_str = '';
        for ($i = 0; $i < $count; $i++) {
            $key = array_rand($name);
            $name_str .= $name[$key];
        }


        return $name_str;
    }

    /**
     * 根据出生日期计算年龄、生肖、星座
     * @param string $birthday = "2018-10-23" 日期
     * @param string $symbol 符号
     * @return mixed
     * */
    public function birthdayInfo($birthday, $symbol = '-') {

        //计算年龄
        $birth = $birthday;
        list($by, $bm, $bd) = explode($symbol, $birth);
        $cm = date('n');
        $cd = date('j');
        $age = date('Y') - $by - 1;
        if ($cm > $bm || $cm == $bm && $cd > $bd) $age++;
        $array['age'] = $age;

        //计算生肖
        $animals = array(
            '鼠', '牛', '虎', '兔', '龙', '蛇',
            '马', '羊', '猴', '鸡', '狗', '猪'
        );
        $key = ($by - 1900) % 12;
        $array['animals'] = $animals[$key];

        //计算星座
        $constellation_name = array(
            '水瓶座', '双鱼座', '白羊座', '金牛座', '双子座', '巨蟹座',
            '狮子座', '处女座', '天秤座', '天蝎座', '射手座', '摩羯座'
        );
        if ($bd <= 22) {
            if ('1' !== $bm) $constellation = $constellation_name[$bm - 2]; else $constellation = $constellation_name[11];
        } else $constellation = $constellation_name[$bm - 1];
        $array['constellation'] = $constellation;

        return $array;
    }

}