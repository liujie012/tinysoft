# tools
tiny框架目录结构

**app**
 - controllers
 - models
 - views
 
**core**
 - common
 - config
 - lib
 - tiny.php

**public**  

**index.php**

数据库 tiebazhushou.sql
数据库配置文件 core/config/database.php